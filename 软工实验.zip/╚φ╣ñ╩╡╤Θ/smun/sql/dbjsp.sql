/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 80013
Source Host           : localhost:3306
Source Database       : dbjsp

Target Server Type    : MYSQL
Target Server Version : 80013
File Encoding         : 65001

Date: 2019-08-07 16:44:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for person
-- ----------------------------
DROP TABLE IF EXISTS `person`;
CREATE TABLE `person` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '记录id',
  `pId` varchar(20) DEFAULT NULL COMMENT '身份证',
  `name` varchar(20) DEFAULT NULL COMMENT '姓名',
  `sex` varchar(4) DEFAULT NULL COMMENT '性别',
  `birthdate` datetime DEFAULT NULL COMMENT '出生日期',
  `img` varchar(120) DEFAULT 'D:\\\\eclipse\\\\workspace\\\\Text92\\\\WebContent\\\\imgfile\\\\1.jpg' COMMENT '学生个人照片',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1600502252 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of person
-- ----------------------------
INSERT INTO `person` VALUES ('112', '113', '的撒3', '阿', '2000-09-09 00:00:00', 'D:\\\\eclipse\\\\workspace\\\\Text92\\\\WebContent\\\\imgfile\\\\1.jpg');
INSERT INTO `person` VALUES ('113', '114', '的撒4', '阿', '2000-09-09 00:00:00', null);
INSERT INTO `person` VALUES ('1600502241', '113', '的撒35', '阿', '2000-09-09 00:00:00', 'D:\\\\eclipse\\\\workspace\\\\Text92\\\\WebContent\\\\imgfile\\\\1.jpg');
INSERT INTO `person` VALUES ('1600502242', '114', '的撒4', '阿', '2000-09-09 00:00:00', 'D:\\\\eclipse\\\\workspace\\\\Text92\\\\WebContent\\\\imgfile\\\\1.jpg');
INSERT INTO `person` VALUES ('1600502248', '4414**************', '男', '男', '2000-04-27 00:00:00', null);
INSERT INTO `person` VALUES ('1600502250', '123', '的撒', '阿', '2000-09-09 00:00:00', null);

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `id` varchar(11) NOT NULL DEFAULT '' COMMENT '工号',
  `name` varchar(20) DEFAULT NULL COMMENT '姓名',
  `age` varchar(4) DEFAULT NULL COMMENT '年龄',
  `title` varchar(20) DEFAULT NULL COMMENT '职称',
  `department` varchar(20) DEFAULT NULL COMMENT '所在系',
  `course` varchar(20) DEFAULT NULL COMMENT '教授课程',
  `phone` varchar(20) DEFAULT NULL COMMENT '电话号码',
  `address` varchar(20) DEFAULT NULL COMMENT '地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('1600502202', '小二', '2', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502203', '小三', '3', '讲师', '软工', 'JAVA', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502204', '小四', '4', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502205', '小五', '5', '讲师', '软工', 'JAVA', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502206', '小六', '6', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502207', '小七', '7', '讲师', '软工', 'JAVA', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502208', '小八', '8', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502209', '小九', '9', '讲师', '软工', 'JAVA', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502210', '小十', '10', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502212', '小十二', '12', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502221', '小一', '1', '讲师', '软工', 'JAVA', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502223', '小三', '3', '讲师', '软工', 'JAVA', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502224', '小四', '4', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502225', '小五', '5', '讲师', '软工', 'JAVA', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502226', '小六', '6', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502227', '小七', '7', '讲师', '软工', 'JAVA', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502228', '小八', '8', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502229', '小九', '9', '讲师', '软工', 'JAVA', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502230', '小十', '10', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502231', '小十一', '11', '讲师', '软工', 'JAVA', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502232', '小十二', '12', '讲师', '软工', '计算机', '15911111111', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502271', '小一', '1', '讲师', '软工', 'JAVA', '15922222222', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502272', '小二', '2', '讲师', '软工', '计算机', '15922222222', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502273', '小三', '3', '讲师', '软工', 'JAVA', '15922222222', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502274', '小四', '4', '讲师', '软工', '计算机', '15922222222', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502275', '小五', '5', '讲师', '软工', 'JAVA', '15922222222', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502276', '小六', '6', '讲师', '软工', '计算机', '15922222222', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502277', '小七', '7', '讲师', '软工', 'JAVA', '15922222222', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502278', '小八', '8', '讲师', '软工', '计算机', '15922222222', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502279', '小九', '9', '讲师', '软工', 'JAVA', '15922222222', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502280', '小十', '10', '讲师', '软工', '计算机', '15933333333', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502281', '小十一', '11', '讲师', '软工', 'JAVA', '15933333333', '西南民族大学');
INSERT INTO `teacher` VALUES ('1600502282', '小十二', '12', '讲师', '软工', '计算机', '15933333333', '西南民族大学');
INSERT INTO `teacher` VALUES ('666666', '小6', '10', '讲师', '信工', '软工', '15933333333', '西南民族大学');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `username` varchar(11) NOT NULL DEFAULT '0',
  `password` varchar(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Text9用户';

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('Admin', '123456');
INSERT INTO `user` VALUES ('admin2', 'admin');
