package entity;
import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import jxl.Workbook;
import jxl.Sheet;
import dao.*;
import entity.JavaBean;

public class ExcelToDb {
	 /**
     * 导入获取的文件数据到数据库中
     */
    public static void excelToDb() {
    	
        //得到表格中所有的数据
        List< JavaBean > listExcel=ExcelToDb.getAllByExcel("c://1.xls");
        
        StudentDao db=new StudentDao();
        
        for (JavaBean stuEntity : listExcel) {
        	
            int id=stuEntity.getId();//获取学号id
            
            //判断学号id是否存在，若已存在，则对该条记录执行更新操作，否则插入。
            if (!isExist(id)) {
            
                String sql="insert into person (id,pId,name,sex,birthdate) values(?,?,?,?,?)";
                String[] str=new String[]{id+"",stuEntity.getpId(),stuEntity.getName(),stuEntity.getSex(),stuEntity.getBirthdate()+""};
                db.AddU(sql, str);
            }else {
          
                String sql="update person set pId=?,name=?,sex=?,birthdate=? where id=?";
                String[] str=new String[]{stuEntity.getpId(),stuEntity.getName(),stuEntity.getSex(),stuEntity.getBirthdate()+"",id+""};
                db.AddU(sql, str);
            }
        }
    }
    
    /**
     * 根据excel文件路径获取数据
     * @param file excel文件路径
     * @return
     */
    public static List<JavaBean> getAllByExcel(String file){
        List<JavaBean> list=new ArrayList<JavaBean>();
        try {
            Workbook rwb=Workbook.getWorkbook(new File(file));
            Sheet rs=rwb.getSheet("test");//或者rwb.getSheet(0)
            int clos=rs.getColumns();//得到所有的列
            int rows=rs.getRows();//得到所有的行
            
            System.out.println("clos:"+clos+" rows:"+(rows-1));
            for (int i = 1; i < rows; i++) {
                for (int j = 0; j < clos; j++) {
                    //第一个是列数，第二个是行数
                    String id=rs.getCell(j++, i).getContents();//默认最左边编号也算一列 所以这里得j++
                    String pId=rs.getCell(j++, i).getContents();
                    String name=rs.getCell(j++, i).getContents();
                    String sex=rs.getCell(j++, i).getContents();
                    String bd=rs.getCell(j++, i).getContents();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    java.sql.Date birthdate=StudentDao.utilToSql(sdf.parse(bd));
                    
                    System.out.println("id:"+id+"  pId:"+pId+"  name:"+name+"  sex:"+sex+"  birthdate:"+birthdate);
                    list.add(new JavaBean(Integer.parseInt(id), pId,name, sex, birthdate));
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } 
        return list;
        
    }
    
    /**
     * 通过学号Id判断学生是否存在
     * @param id
     * @return
     */
	public static boolean isExist(int id){
        try {
        	StudentDao db=new StudentDao();
            ResultSet rs=db.Search("select * from person where id=?", new String[]{id+""});
            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }
    
}
