package entity;

import java.io.File;
import java.sql.Date;

public class JavaBean {
	private int id;
	private String pId;
	private String name;
	private String sex;
	private Date birthdate;
	
	public void setId(int id) {
		this.id=id;
	}
	public int getId() {
		return id;
	}
	
	public void setpId(String pId) {
		this.pId=pId;
	}
	public String getpId() {
		return pId;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	public String getName() {
		return name;
	}
	
	public void setSex(String sex) {
		this.sex=sex;
	}
	public String getSex() {
		return sex;
	}
	
	public void setBirthdate(Date birthdate) {
		this.birthdate=birthdate;
	}
	public Date getBirthdate() {
		return birthdate;
	}
	public JavaBean(int id,String pId,String name,String sex,Date birthdate) {
		super();
		this.id=id;
		this.name=name;
		this.pId=pId;
		this.sex=sex;
		this.birthdate=birthdate;
	}
	
	public static int getX(String x[]) {
			int j=0;
			while(j<x.length) {
				System.out.println(x[j]);
				j++;
			}
			return j;
			
				
	}
		
	public static void DBCheck(int id) {
		 
	}
	
}
