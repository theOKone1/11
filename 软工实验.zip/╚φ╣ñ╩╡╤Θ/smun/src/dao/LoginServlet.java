package dao;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")

public class LoginServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 4069971059282821774L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

		//设置编码格式，确保发往服务器的参数以utf-8的编码来提取
        request.setCharacterEncoding("utf-8");

        //获取input标签输入的账号密码值，注意request.getParameter("XXX")与该标签下name属性值XXX相同
        String piccode=(String) request.getSession().getAttribute("piccode");
        String checkCode=request.getParameter("checkCode");  //取值
        //checkCode=checkCode.toUpperCase();  //把字符全部转换为大写的（此语句可以用于验证码不区分大小写）
        String userName = request.getParameter("username");
        String userPwd = request.getParameter("password");
        
        if(checkCode.equals(piccode)) {

        //验证账号密码是否正确
        if(StudentDao.checkLogin(userName, userPwd)) {

            HttpSession session = request.getSession();

            session.setAttribute("loginName", userName);

            response.sendRedirect("../show.jsp");
        } 
        }else {
 
            response.sendRedirect("../fail.html");
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}
